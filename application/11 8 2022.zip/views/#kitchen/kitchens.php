
<section class="main-content-wrapper">
    <?php
    if ($this->session->flashdata('exception')) {

        echo '<section class="alert-wrapper">
        <div class="alert alert-success alert-dismissible fade show"> 
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <div class="alert-body">
        <p><i class="m-right fa fa-check"></i>';
        echo escape_output($this->session->flashdata('exception'));
        echo '</p></div></div></section>';
    }
    ?>

    <section class="content-header">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="top-left-header"><?php echo lang('storage'); ?> </h2>
                <input type="hidden" class="datatable_name" data-title="<?php echo lang('storage'); ?>" data-id_name="datatable">
            </div>
            <div>
                <a class="btn_list btn bg-blue-btn m-right" href="<?php echo base_url() ?>Kitchen/addEditKitchen">
                    <i data-feather="plus"></i> <?php echo lang('add_storage'); ?>
                </a>
            </div>
        </div>
    </section>


    <div class="box-wrapper">
        <!-- general form elements -->
        <div class="table-box">
            <!-- /.box-header -->
            <div class="table-responsive">
                <table id="datatable" class="table">
                    <thead>
                    <tr>
                        <th class="ir_w_1"> <?php echo lang('sn'); ?></th>
                        <th class="ir_w_30"><?php echo lang('name'); ?></th>
                        <th class="ir_w_15"><?php echo lang('ViaPrinter'); ?></th>
                        <th class="ir_w_30"><?php echo lang('categories'); ?></th>
                        <th class="ir_w_8"></th>
                        <th class="ir_w_1 ir_txt_center not-export-col"><?php echo lang('actions'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if ($kitchens && !empty($kitchens)) {
                        $i = count($kitchens);
                    }
                    foreach ($kitchens as $kitchen) { ?>
                        <tr>
                            <td class="ir_txt_center"><?php echo escape_output($i--); ?></td>
                            <td><?php echo escape_output($kitchen->name) ?></td>
                            <td><?php echo escape_output(isset($kitchen->kitchen_use_type) && $kitchen->kitchen_use_type==1?lang('ViaPanel'):lang('ViaPrinter')." (".escape_output(getPrinter($kitchen->printer_id)).")") ?></td>
                            <td><?php echo escape_output($kitchen->categories) ?></td>
                            <td>
                                <a target="_blank" href="<?php echo base_url()?>Kitchen/panel/<?php echo escape_output($kitchen->id)?>" class="btn btn-primary btn-xs"><?php echo lang('enter'); ?></a>
                            </td>
                            <td class="ir_txt_center">
                                <div class="btn-group  actionDropDownBtn">
                                    <button type="button" class="btn bg-blue-color dropdown-toggle"
                                            id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i data-feather="more-vertical"></i>
                                    </button>

                                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton1"
                                        role="menu">
                                        <li>
                                            <a  href="<?php echo base_url() ?>Kitchen/addEditKitchen/<?php echo escape_output($this->custom->encrypt_decrypt($kitchen->id, 'encrypt')); ?>"><i
                                                    class="fa fa-pencil tiny-icon"></i><?php echo lang('edit'); ?></a>
                                        </li>
                                        <li>
                                            <a class="delete"
                                               href="<?php echo base_url() ?>Kitchen/deleteKitchen/<?php echo escape_output($this->custom->encrypt_decrypt($kitchen->id, 'encrypt')); ?>"><i
                                                    class="fa fa-trash tiny-icon"></i><?php echo lang('delete'); ?></a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section><script src="<?php echo base_url(); ?>frequent_changing/js/inventory.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>assets/datatable_custom/jquery-3.3.1.js"></script>
<script src="<?php echo base_url(); ?>frequent_changing/js/dataTable/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatable_custom/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>frequent_changing/js/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatable_custom/buttons.flash.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatable_custom/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatable_custom/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatable_custom/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/datatable_custom/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatable_custom/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>frequent_changing/newDesign/js/forTable.js"></script>

<script src="<?php echo base_url(); ?>frequent_changing/js/custom_report.js"></script>